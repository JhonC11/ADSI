<?php 
	require 'load.php';
	require 'model.php';
	require 'controller.php';
	new Controller();
 ?>